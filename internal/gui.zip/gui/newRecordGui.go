package gui

import (
	"time"

	"github.com/Judisk/daily-tracker-cli/internal/model"
	"github.com/Judisk/daily-tracker-cli/internal/sleep"
	"github.com/Judisk/daily-tracker-cli/internal/storage"
)

func saveGui(fields []*inputField) error {
	if err := storage.Save(collectRecord(fields)); err != nil {
		return err
	}
	return nil
}

func collectRecord(fields []*inputField) model.Record {
	values := map[string]any{}

	for _, f := range fields {
		values[f.config.Prompt()] = f.value
	}

	sleepDuration := sleep.Duration(
		values["WokeUp"].(time.Time),
		values["FellAsleep"].(time.Time),
	)
	return model.Record{
		WentToBed:     values["WentToBed"].(time.Time),
		FellAsleep:    values["FellAsleep"].(time.Time),
		WokeUp:        values["WokeUp"].(time.Time),
		TookMeds:      values["TookMeds"].(time.Time),
		SleepDuration: sleepDuration,

		SleepQuality: values["SleepQuality"].(int),
		Mood:         values["Mood"].(int),
		Energy:       values["Energy"].(int),
		Focus:        values["Focus"].(int),
		Pills:        values["Pills"].(int),
	}
}
